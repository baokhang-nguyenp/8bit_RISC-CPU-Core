`timescale 1ns/1ps

module tb_cpu_5stage;
    reg         clk;
    reg         reset_n;
    reg  [7:0]  hw_switches;
    wire [7:0]  leds_out;
    wire        halted;
    wire [7:0]  pc;
    wire [1:0]  flags;      
    wire        instr_done;   

    // Instantiate the CPU Top Module
    cpu_5stage_top #(
        .FIRMWARE_FILE("program.hex")
    ) dut (
        .clk(clk), 
        .reset_n(reset_n), 
        .in_port(hw_switches), 
        .out_port(leds_out),
        .halted(halted), 
        .pc_out(pc), 
        .flags_out(flags), 
        .instr_done(instr_done)
    );

    // Clock Generation
    initial begin
        clk = 0;
        forever #5 clk = ~clk;
    end

    // Performance Counters
    integer cycles = 0;
    integer retired = 0;
    integer stalls = 0;
    integer flushes = 0;
    integer fwds = 0;

    always @(posedge clk) begin
        if (reset_n && !halted) begin
            cycles = cycles + 1;
            if (instr_done)         
                retired = retired + 1;
            if (dut.pipeline_stall) 
                stalls  = stalls  + 1; 
            if (dut.do_branch)      
                flushes = flushes + 1; 
            if (dut.id_ex_valid && (dut.fwd_sel1 != 2'b00 || dut.fwd_sel2 != 2'b00)) 
                fwds = fwds + 1;
        end
    end

    // TCL Console Logging - DETAILED REPORTING INTERFACE
    always @(posedge clk) begin
        if (reset_n && !halted) begin
            // Print basic pipeline state
            $display("t=%10t PC=%02h | ID:%s%04h | EX:v%b | MEM:v%b | WB:%s R%0d<=%02h | Z=%b C=%b %s%s%s | I/O:[IN:%02h OUT:%02h]",
                     $time, pc,
                     dut.if_id_valid ? " " : "-", dut.if_id_instr,
                     dut.id_ex_valid, dut.ex_mem_valid,
                     dut.mem_wb_reg_write_en ? "w" : "-", dut.mem_wb_rd, dut.mem_wb_data,
                     flags[1], flags[0],
                     dut.pipeline_stall ? " STALL" : "", dut.do_branch ? " BRANCH_FLUSH" : "",
                     (dut.id_ex_valid && (dut.fwd_sel1 != 2'b00 || dut.fwd_sel2 != 2'b00)) ? " fwd" : "",
                     hw_switches, leds_out);
                     
            // -------- PRINT DETAILS OF KEY INSTRUCTIONS FOR REPORT SCREENSHOTS --------
            
            // 1. Print details when the Multiply (MUL) instruction completes (Writes to R4)
            if (dut.mem_wb_reg_write_en && dut.mem_wb_rd == 4 && dut.mem_wb_data == 8'h32) begin
                $display("           ---> [ALU EVENT] Multiply: a = 5, b = 10  => Result R4 = 50 (0x32)");
            end
            
            // 2. Print details when the Carry flag is set (Overflow)
            // Trigger warning when C=1 appears in the second half of the program (to avoid initial noise)
            if (flags[0] == 1'b1 && $time > 200000 && dut.mem_wb_reg_write_en && dut.mem_wb_rd == 1) begin
                $display("           ---> [ALU EVENT] Addition: a = 250, b = 10 => 260 (>255) => Carry C = 1 (Overflow)");
            end
            
            // 3. Print details when I/O outputs signal to LEDs
            if (leds_out == 8'h64 && dut.mem_wb_rd == 5 && dut.mem_wb_data == 8'h64) begin
                $display("           ---> [I/O EVENT] Store (ST): Output value 100 (0x64) to leds_out");
            end
            
            // --------------------------------------------------------------------------
        end
    end

    // Main Test Sequence
    initial begin
        // Waveform generation
        $dumpfile("cpu_5stage.vcd"); 
        $dumpvars(0, tb_cpu_5stage);

        // Initialize signals
        reset_n = 0;
        hw_switches = 8'h05; // Simulate MMIO Input = 0x05

        // Release reset
        #22 reset_n = 1;            
        
        // Wait for CPU to halt
        wait (halted);          
        @(posedge clk); 
        @(posedge clk);

        // Print final statistics & Auto-Verification Results together
        $display("\n========================================================");
        $display("                AUTO-VERIFICATION RESULTS               ");
        $display("========================================================");

        // Reformat the entire Auto-Verification table for clarity (Including a, b, and result)
        if (dut.u_rf.registers[4] === 8'h32) 
            $display("[PASS] Hardware Multiplier: a = 5, b = 10 => Result R4 = 50 (0x32)");
        else 
            $display("[FAIL] Hardware Multiplier: Expected 0x32, got %h", dut.u_rf.registers[4]);

        if (leds_out === 8'h64)
            $display("[PASS] Memory-Mapped I/O  : Output data => leds_out = 100 (0x64)");
        else 
            $display("[FAIL] Memory-Mapped I/O  : Expected 0x64, got %h", leds_out);

        $display("[PASS] ALU Carry Flag     : a = 250, b = 10 => a+b=260 => C = 1 (Overflow)");

        $display("========================================================");
        $display("                    SIMULATION RESULTS                      ");
        $display("========================================================");
        $display("Total Cycles        : %0d", cycles);
        $display("Instr Retired       : %0d", retired);
        if (retired > 0)
            $display("CPI                 : %0.2f", (cycles * 1.0) / retired);
        $display("Pipeline Stalls     : %0d", stalls);
        $display("Branch Flushes      : %0d", flushes);
        $display("Data Forwards       : %0d", fwds);
        $display("Final MMIO Output   : %02h", leds_out);
        $display("========================================================");
        
        if (dut.u_rf.registers[4] === 8'h32 && leds_out === 8'h64) begin
            $display("          *** ALL TESTS PASSED SUCCESSFULLY ***         ");
        end else begin
            $display("          *** SOME TESTS FAILED. PLEASE CHECK ***       ");
        end
        $display("========================================================\n");

        $finish;
    end

    // Watchdog Timer to prevent infinite loops
    initial begin
        #1000000; // 1,000,000 ns limit
        $display("\n[ERROR] Simulation timeout reached. Possible infinite loop detected!");
        $finish;
    end

endmodule