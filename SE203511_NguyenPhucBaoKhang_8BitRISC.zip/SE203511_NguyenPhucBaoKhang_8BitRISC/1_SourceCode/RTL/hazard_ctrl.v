`timescale 1ns/1ps

module hazard_ctrl (
    input  wire       id_valid,
    input  wire [2:0] id_port1_addr,
    input  wire [2:0] id_port2_addr,
    input  wire       id_read_port1,
    input  wire       id_read_port2,

    input  wire       ex_valid,
    input  wire       ex_mem_to_reg,
    input  wire [2:0] ex_dest_reg,
    input  wire [2:0] ex_port1_addr,
    input  wire [2:0] ex_port2_addr,
    input  wire       ex_read_port1,
    input  wire       ex_read_port2,

    input  wire       mem_reg_write_en,
    input  wire       mem_mem_to_reg,
    input  wire [2:0] mem_dest_reg,

    input  wire       wb_reg_write_en,
    input  wire [2:0] wb_dest_reg,

    output reg  [1:0] fwd_sel1,
    output reg  [1:0] fwd_sel2,
    output wire       pipeline_stall
);

    always @(*) begin
        if (ex_read_port1 && mem_reg_write_en && !mem_mem_to_reg && (mem_dest_reg == ex_port1_addr))
            fwd_sel1 = 2'b10;
        else if (ex_read_port1 && wb_reg_write_en && (wb_dest_reg == ex_port1_addr))
            fwd_sel1 = 2'b01;
        else
            fwd_sel1 = 2'b00;
    end

    always @(*) begin
        if (ex_read_port2 && mem_reg_write_en && !mem_mem_to_reg && (mem_dest_reg == ex_port2_addr))
            fwd_sel2 = 2'b10;
        else if (ex_read_port2 && wb_reg_write_en && (wb_dest_reg == ex_port2_addr))
            fwd_sel2 = 2'b01;
        else
            fwd_sel2 = 2'b00;
    end

    assign pipeline_stall = id_valid && ex_valid && ex_mem_to_reg &&
                            ((id_read_port1 && (id_port1_addr == ex_dest_reg)) ||
                             (id_read_port2 && (id_port2_addr == ex_dest_reg)));
endmodule