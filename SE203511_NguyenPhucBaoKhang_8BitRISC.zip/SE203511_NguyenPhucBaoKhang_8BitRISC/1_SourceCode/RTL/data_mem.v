`timescale 1ns/1ps

module data_mem (
    input  wire       clk,
    input  wire       write_enable,
    input  wire [7:0] mem_addr,
    input  wire [7:0] write_data,
    output wire [7:0] read_data
);

    reg [7:0] d_ram [0:255];
    integer i;

    initial begin
        for (i = 0; i < 256; i = i + 1) d_ram[i] = 8'h00;
    end

    always @(posedge clk) begin
        if (write_enable) d_ram[mem_addr] <= write_data;
    end

    assign read_data = d_ram[mem_addr];

endmodule