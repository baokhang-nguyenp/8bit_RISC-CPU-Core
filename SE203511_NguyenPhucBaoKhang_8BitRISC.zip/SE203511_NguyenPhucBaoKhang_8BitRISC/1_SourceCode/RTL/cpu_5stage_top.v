`timescale 1ns/1ps

module cpu_5stage_top #(
    parameter FIRMWARE_FILE = "program.hex"
) (
    input  wire       clk,
    input  wire       reset_n,
    input  wire [7:0] in_port,  
    output reg  [7:0] out_port, 
    output reg        halted,
    output wire [7:0] pc_out,
    output wire [1:0] flags_out,
    output wire       instr_done
);

    // ================== Stage 1 (IF) ==================
    reg  [7:0]  pc_reg;
    wire [15:0] fetch_instr;

    inst_mem #(.FIRMWARE_FILE(FIRMWARE_FILE)) u_imem (
        .pc_addr(pc_reg),
        .instruction(fetch_instr)
    );

    reg [15:0] if_id_instr;
    reg        if_id_valid;

    // ================== Stage 2 (ID) ==================
    wire [3:0] id_op_code = if_id_instr[15:12];
    wire [2:0] id_rd      = if_id_instr[11:9];
    wire [2:0] id_rs1     = if_id_instr[8:6];
    wire [2:0] id_rs2     = if_id_instr[5:3];
    wire [7:0] id_imm     = if_id_instr[7:0];

    wire [3:0] id_alu_ctrl; 
    wire id_use_imm, id_port1_is_rd, id_port2_is_rd, id_read_port1, id_read_port2,
         id_reg_write_en, id_mem_to_reg, id_mem_write_en, id_update_flags,
         id_is_jmp, id_is_bz, id_is_bnz, id_is_halt;

    ctrl_decode u_ctrl (
        .op_code(id_op_code), .alu_ctrl(id_alu_ctrl), .use_imm(id_use_imm),
        .port1_is_rd(id_port1_is_rd), .port2_is_rd(id_port2_is_rd),
        .read_port1(id_read_port1), .read_port2(id_read_port2),
        .reg_write_en(id_reg_write_en), .mem_to_reg(id_mem_to_reg),
        .mem_write_en(id_mem_write_en), .update_flags(id_update_flags),
        .is_jmp(id_is_jmp), .is_bz(id_is_bz), .is_bnz(id_is_bnz), .is_halt(id_is_halt)
    );

    wire [2:0] id_port1_addr = id_port1_is_rd ? id_rd : id_rs1;
    wire [2:0] id_port2_addr = id_port2_is_rd ? id_rd : id_rs2;
    wire [7:0] id_port1_data, id_port2_data;

    reg        mem_wb_valid, mem_wb_reg_write_en, mem_wb_halt;
    reg  [2:0] mem_wb_rd;
    reg  [7:0] mem_wb_data;
    wire [7:0] wb_final_data = mem_wb_data;

    reg_bank u_rf (
        .clk(clk), .reset_n(reset_n),
        .port1_addr(id_port1_addr), .port1_data(id_port1_data),
        .port2_addr(id_port2_addr), .port2_data(id_port2_data),
        .write_en(mem_wb_reg_write_en), .dest_addr(mem_wb_rd), .write_data(wb_final_data)
    );

    reg        id_ex_valid, id_ex_use_imm, id_ex_read_port1, id_ex_read_port2;
    reg  [3:0] id_ex_alu_ctrl; 
    reg        id_ex_reg_write_en, id_ex_mem_to_reg, id_ex_mem_write_en, id_ex_update_flags;
    reg        id_ex_is_jmp, id_ex_is_bz, id_ex_is_bnz, id_ex_is_halt;
    reg  [2:0] id_ex_rd, id_ex_port1_addr, id_ex_port2_addr;
    reg  [7:0] id_ex_port1_data, id_ex_port2_data, id_ex_imm;

    reg        ex_mem_valid, ex_mem_reg_write_en, ex_mem_mem_to_reg, ex_mem_mem_write_en, ex_mem_halt;
    reg  [2:0] ex_mem_rd;
    reg  [7:0] ex_mem_alu_res, ex_mem_addr, ex_mem_store_data;

    wire [1:0] fwd_sel1, fwd_sel2;
    wire       pipeline_stall;

    hazard_ctrl u_hazard (
        .id_valid(if_id_valid), .id_port1_addr(id_port1_addr), .id_port2_addr(id_port2_addr),
        .id_read_port1(id_read_port1), .id_read_port2(id_read_port2),
        .ex_valid(id_ex_valid), .ex_mem_to_reg(id_ex_mem_to_reg), .ex_dest_reg(id_ex_rd),
        .ex_port1_addr(id_ex_port1_addr), .ex_port2_addr(id_ex_port2_addr),
        .ex_read_port1(id_ex_read_port1), .ex_read_port2(id_ex_read_port2),
        .mem_reg_write_en(ex_mem_reg_write_en), .mem_mem_to_reg(ex_mem_mem_to_reg), .mem_dest_reg(ex_mem_rd),
        .wb_reg_write_en(mem_wb_reg_write_en), .wb_dest_reg(mem_wb_rd),
        .fwd_sel1(fwd_sel1), .fwd_sel2(fwd_sel2), .pipeline_stall(pipeline_stall)
    );

    // ================== Stage 3 (EX) ==================
    wire [7:0] ex_opA = (fwd_sel1 == 2'b10) ? ex_mem_alu_res :
                        (fwd_sel1 == 2'b01) ? wb_final_data  : id_ex_port1_data;
    wire [7:0] ex_opB = (fwd_sel2 == 2'b10) ? ex_mem_alu_res :
                        (fwd_sel2 == 2'b01) ? wb_final_data  : id_ex_port2_data;
    wire [7:0] ex_alu_b = id_ex_use_imm ? id_ex_imm : ex_opB;
    
    wire [7:0] ex_alu_out;
    wire       ex_carry_flag, ex_zero_flag;
    
    alu_core u_alu (
        .op_a(ex_opA), .op_b(ex_alu_b), .alu_ctrl(id_ex_alu_ctrl),
        .alu_out(ex_alu_out), .carry_flag(ex_carry_flag), .zero_flag(ex_zero_flag)
    );

    reg flag_z, flag_c;
    wire do_branch = id_ex_valid && (id_ex_is_jmp || (id_ex_is_bz && flag_z) || (id_ex_is_bnz && !flag_z));
    wire [7:0] branch_tgt = id_ex_imm;
    
    wire ex_halt = id_ex_valid && id_ex_is_halt;
    reg  is_draining;
    wire stop_fetch = is_draining || ex_halt;

    // ================== Stage 4 (MEM) ==================
    wire [7:0] mem_rdata;
    // MMIO Logic
    wire       is_mmio_out = (ex_mem_addr == 8'hFF) && ex_mem_mem_write_en && !halted;
    wire       is_mem_wen  = (ex_mem_addr < 8'hFE)  && ex_mem_mem_write_en && !halted; 

    data_mem u_dmem (
        .clk(clk), .write_enable(is_mem_wen), .mem_addr(ex_mem_addr),
        .write_data(ex_mem_store_data), .read_data(mem_rdata)
    );
    
    wire [7:0] mem_final_res = ex_mem_mem_to_reg ? 
                               ((ex_mem_addr == 8'hFE) ? in_port : mem_rdata) 
                               : ex_mem_alu_res;

    // ================== Sequential Logic ==================
    always @(posedge clk) begin
        if (!reset_n) begin
            out_port <= 8'h00;
            pc_reg <= 8'h00;
            if_id_instr <= 16'h0000; if_id_valid <= 1'b0;
            id_ex_valid <= 1'b0; id_ex_alu_ctrl <= 4'd0; id_ex_use_imm <= 1'b0;
            id_ex_read_port1 <= 1'b0; id_ex_read_port2 <= 1'b0; id_ex_reg_write_en <= 1'b0;
            id_ex_mem_to_reg <= 1'b0; id_ex_mem_write_en <= 1'b0; id_ex_update_flags <= 1'b0;
            id_ex_is_jmp <= 1'b0; id_ex_is_bz <= 1'b0; id_ex_is_bnz <= 1'b0; id_ex_is_halt <= 1'b0;
            id_ex_rd <= 3'd0; id_ex_port1_addr <= 3'd0; id_ex_port2_addr <= 3'd0;
            id_ex_port1_data <= 8'h00; id_ex_port2_data <= 8'h00; id_ex_imm <= 8'h00;
            ex_mem_valid <= 1'b0; ex_mem_reg_write_en <= 1'b0; ex_mem_mem_to_reg <= 1'b0;
            ex_mem_mem_write_en <= 1'b0; ex_mem_halt <= 1'b0; ex_mem_rd <= 3'd0;
            ex_mem_alu_res <= 8'h00; ex_mem_addr <= 8'h00; ex_mem_store_data <= 8'h00;
            mem_wb_valid <= 1'b0; mem_wb_reg_write_en <= 1'b0; mem_wb_rd <= 3'd0;
            mem_wb_data <= 8'h00; mem_wb_halt <= 1'b0;
            flag_z <= 1'b0; flag_c <= 1'b0;
            is_draining <= 1'b0; halted <= 1'b0;
        end else if (!halted) begin
            // MMIO Output
            if (is_mmio_out) out_port <= ex_mem_store_data;
            
            // ------------- IF/ID -------------
            if (do_branch) begin
                pc_reg <= branch_tgt; if_id_instr <= 16'h0000; if_id_valid <= 1'b0;
            end else if (stop_fetch) begin
                if_id_instr <= 16'h0000; if_id_valid <= 1'b0;
            end else if (!pipeline_stall) begin
                pc_reg <= pc_reg + 8'd1; if_id_instr <= fetch_instr; if_id_valid <= 1'b1;
            end

            // ------------- ID/EX -------------
            if (do_branch || stop_fetch || pipeline_stall) begin
                id_ex_valid <= 1'b0;
            end else begin
                id_ex_valid <= if_id_valid; id_ex_alu_ctrl <= id_alu_ctrl;
                id_ex_use_imm <= id_use_imm; id_ex_read_port1 <= id_read_port1;
                id_ex_read_port2 <= id_read_port2; id_ex_reg_write_en <= id_reg_write_en;
                id_ex_mem_to_reg <= id_mem_to_reg; id_ex_mem_write_en <= id_mem_write_en;
                id_ex_update_flags <= id_update_flags; id_ex_is_jmp <= id_is_jmp;
                id_ex_is_bz <= id_is_bz; id_ex_is_bnz <= id_is_bnz; id_ex_is_halt <= id_is_halt;
                id_ex_rd <= id_rd; id_ex_port1_addr <= id_port1_addr;
                id_ex_port2_addr <= id_port2_addr; id_ex_port1_data <= id_port1_data;
                id_ex_port2_data <= id_port2_data; id_ex_imm <= id_imm;
            end

            // ------------- EX/MEM -------------
            ex_mem_valid <= id_ex_valid;
            ex_mem_reg_write_en <= id_ex_valid && id_ex_reg_write_en;
            ex_mem_mem_to_reg <= id_ex_valid && id_ex_mem_to_reg;
            ex_mem_mem_write_en <= id_ex_valid && id_ex_mem_write_en;
            ex_mem_halt <= ex_halt;
            ex_mem_rd <= id_ex_rd;
            ex_mem_alu_res <= ex_alu_out;
            ex_mem_addr <= ex_opA;
            ex_mem_store_data <= ex_opB;
            
            if (id_ex_valid && id_ex_update_flags) begin
                flag_z <= ex_zero_flag;
                flag_c <= ex_carry_flag;
            end
            
            if (ex_halt) is_draining <= 1'b1;

            // ------------- MEM/WB -------------
            mem_wb_valid <= ex_mem_valid;
            mem_wb_reg_write_en <= ex_mem_reg_write_en;
            mem_wb_rd <= ex_mem_rd;
            mem_wb_data <= mem_final_res;
            mem_wb_halt <= ex_mem_halt;
            
            if (mem_wb_halt) halted <= 1'b1;
        end else begin
            mem_wb_reg_write_en <= 1'b0;
        end
    end

    assign pc_out = pc_reg;
    assign flags_out = {flag_z, flag_c};
    assign instr_done = mem_wb_valid;
endmodule