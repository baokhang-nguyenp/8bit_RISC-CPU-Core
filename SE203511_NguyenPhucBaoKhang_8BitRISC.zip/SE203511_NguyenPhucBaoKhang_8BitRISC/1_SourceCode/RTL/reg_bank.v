`timescale 1ns/1ps

module reg_bank (
    input  wire       clk,
    input  wire       reset_n, 
    input  wire [2:0] port1_addr,
    output wire [7:0] port1_data,
    input  wire [2:0] port2_addr,
    output wire [7:0] port2_data,
    input  wire       write_en,
    input  wire [2:0] dest_addr,
    input  wire [7:0] write_data
);

    reg [7:0] registers [0:7];
    integer idx;

    always @(posedge clk) begin
        if (!reset_n) begin
            for (idx = 0; idx < 8; idx = idx + 1) begin
                registers[idx] <= 8'h00;
            end
        end else if (write_en) begin
            registers[dest_addr] <= write_data;
        end
    end

    assign port1_data = (write_en && (dest_addr == port1_addr)) ? write_data : registers[port1_addr];
    assign port2_data = (write_en && (dest_addr == port2_addr)) ? write_data : registers[port2_addr];

endmodule