`timescale 1ns/1ps

module ctrl_decode (
    input  wire [3:0] op_code,
    output reg  [3:0] alu_ctrl,
    output reg        use_imm, port1_is_rd, port2_is_rd, read_port1, read_port2,
    output reg        reg_write_en, mem_to_reg, mem_write_en, update_flags,
    output reg        is_jmp, is_bz, is_bnz, is_halt
);

    localparam OP_MUL=4'h0, OP_ADD=4'h1, OP_SUB=4'h2, OP_AND=4'h3, OP_OR =4'h4, OP_XOR=4'h5,
               OP_SHL=4'h6, OP_SHR=4'h7, OP_LDI=4'h8, OP_ADDI=4'h9, OP_LD=4'hA, OP_ST=4'hB,
               OP_JMP=4'hC, OP_BZ =4'hD, OP_BNZ=4'hE, OP_HLT=4'hF;

    always @(*) begin
        alu_ctrl = 4'd0; use_imm = 0; port1_is_rd = 0; port2_is_rd = 0;
        read_port1 = 0; read_port2 = 0; reg_write_en = 0; mem_to_reg = 0;
        mem_write_en = 0; update_flags = 0; is_jmp = 0; is_bz = 0; is_bnz = 0; is_halt = 0;

        case (op_code)
            OP_MUL : begin alu_ctrl = 4'd8; read_port1 = 1; read_port2 = 1; reg_write_en = 1; update_flags = 1; end
            OP_ADD : begin alu_ctrl = 4'd0; read_port1 = 1; read_port2 = 1; reg_write_en = 1; update_flags = 1; end
            OP_SUB : begin alu_ctrl = 4'd1; read_port1 = 1; read_port2 = 1; reg_write_en = 1; update_flags = 1; end
            OP_AND : begin alu_ctrl = 4'd2; read_port1 = 1; read_port2 = 1; reg_write_en = 1; update_flags = 1; end
            OP_OR  : begin alu_ctrl = 4'd3; read_port1 = 1; read_port2 = 1; reg_write_en = 1; update_flags = 1; end
            OP_XOR : begin alu_ctrl = 4'd4; read_port1 = 1; read_port2 = 1; reg_write_en = 1; update_flags = 1; end
            OP_SHL : begin alu_ctrl = 4'd5; read_port1 = 1; reg_write_en = 1; update_flags = 1; end
            OP_SHR : begin alu_ctrl = 4'd6; read_port1 = 1; reg_write_en = 1; update_flags = 1; end
            OP_LDI : begin alu_ctrl = 4'd7; use_imm = 1; reg_write_en = 1; end
            OP_ADDI: begin alu_ctrl = 4'd0; use_imm = 1; port1_is_rd = 1; read_port1 = 1; reg_write_en = 1; update_flags = 1; end
            OP_LD  : begin read_port1 = 1; reg_write_en = 1; mem_to_reg = 1; end
            OP_ST  : begin read_port1 = 1; read_port2 = 1; port2_is_rd = 1; mem_write_en = 1; end
            OP_JMP : is_jmp = 1; 
            OP_BZ  : is_bz = 1; 
            OP_BNZ : is_bnz = 1; 
            OP_HLT : is_halt = 1;
            default: ;
        endcase
    end
endmodule