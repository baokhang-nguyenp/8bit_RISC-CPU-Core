`timescale 1ns/1ps

module alu_core (
    input  wire [7:0] op_a,
    input  wire [7:0] op_b,
    input  wire [3:0] alu_ctrl, 
    output reg  [7:0] alu_out,
    output reg        carry_flag,
    output wire       zero_flag
);

    localparam CMD_ADD   = 4'd0, CMD_SUB   = 4'd1, CMD_AND   = 4'd2,
               CMD_OR    = 4'd3, CMD_XOR   = 4'd4, CMD_SHL   = 4'd5,
               CMD_SHR   = 4'd6, CMD_PASSB = 4'd7, CMD_MUL   = 4'd8; 

    reg [15:0] mul_res; 

    always @(*) begin
        carry_flag = 1'b0; 
        case (alu_ctrl)
            CMD_ADD:   {carry_flag, alu_out} = {1'b0, op_a} + {1'b0, op_b};
            CMD_SUB:   {carry_flag, alu_out} = {1'b0, op_a} - {1'b0, op_b};
            CMD_AND:   alu_out = op_a & op_b;
            CMD_OR:    alu_out = op_a | op_b;
            CMD_XOR:   alu_out = op_a ^ op_b;
            CMD_SHL:   {carry_flag, alu_out} = {op_a, 1'b0};
            CMD_SHR:   {alu_out, carry_flag} = {1'b0, op_a};
            CMD_PASSB: alu_out = op_b;
            CMD_MUL:   begin 
                           mul_res = op_a * op_b;
                           alu_out = mul_res[7:0]; 
                           carry_flag = (mul_res[15:8] != 8'd0); 
                       end
            default:   alu_out = 8'h00;
        endcase
    end

    assign zero_flag = ~|alu_out; 
endmodule