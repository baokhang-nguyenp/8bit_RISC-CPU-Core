`timescale 1ns/1ps

module inst_mem #(
    parameter FIRMWARE_FILE = "program.hex"
) (
    input  wire [7:0]  pc_addr,
    output wire [15:0] instruction
);

    reg [15:0] mem_array [0:255];
    integer i;

    initial begin
        for (i = 0; i < 256; i = i + 1) mem_array[i] = 16'h0000;
        $readmemh("program.hex", mem_array);
    end

    assign instruction = mem_array[pc_addr];

endmodule